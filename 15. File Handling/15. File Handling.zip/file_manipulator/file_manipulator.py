import os

while True:
    command = input().split("-")
    if "Create" in command:
        file_name = command[1]
        with open(file_name, "w") as file:
            pass

    elif "Add" in command:
        file_name = command[1]
        content = command[2]
        with open(file_name, "a") as file:
            file.write(content)
            file.write("\n")

    elif "Replace" in command:
        file_name = command[1]
        old_string = command[2]
        new_string = command[3]
        if os.path.exists(file_name):
            with open(file_name, "r+") as file:
                new_content = file.read().replace(old_string, new_string)
                file.seek(0)
                file.truncate()
                file.write(new_content)
        else:
            print("An error occurred")

    elif "Delete" in command:
        file_name = command[1]
        if os.path.exists(file_name):
            os.remove(file_name)
        else:
            print("An error occurred")

    elif "End" in command:
        break