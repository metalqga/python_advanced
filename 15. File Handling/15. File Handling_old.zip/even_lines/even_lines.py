symbols = ["-", ",", ".", "!", "?"]

with open("text.txt", "r") as file:
    for row, line in enumerate(file):
        if row % 2 == 0:
            new_line = line.strip().split()  # махни излищния нов ред
            result = (" ".join(reversed(new_line)))

            for symbol in symbols:
                if symbol in symbols:
                    result = result.replace(symbol, "@")
            print(result)
