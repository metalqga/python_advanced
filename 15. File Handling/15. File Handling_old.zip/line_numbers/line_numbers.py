import re

with open("text.txt") as input_file, open("output.txt","w") as output_file:
    for row,line in enumerate(input_file):
        letters_count=len(re.findall("[A-z]",line))
        symbols_count=len(re.findall('[,.\'\":?!\-]',line))
        output_file.write(f"Line {row+1}: {line.strip()} ({letters_count})({symbols_count})\n")